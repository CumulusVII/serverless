# :postbox: serverless [![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](./LICENSE)

aws lambda update-function-code --function-name emailVerify --zip-file fileb://function.zip